# image-resizer
A ready to use php function image resizer

Simply include the resize-function.php file and edit the parameters of the function 

<h3>CreateThumbs($src, $dst, $width, $height, $crop=0)</h3>

<h5>Feel free to use it</h5>
